﻿'This program is a modified version of a course assignment, by S. Daniel Laird via Mycanda.

Public Class frmProject3
    Private Sub frmProject3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblDate.Text = Now.ToShortDateString
        lblTime.Text = Now.ToShortTimeString
        lstMajor.SelectedIndex = 0
    End Sub

    Private Sub btnCheckValues_Click(sender As Object, e As EventArgs) Handles btnCheckValues.Click
        If (txtFirstName.Text = String.Empty) Then
            MessageBox.Show("Please enter a First Name!", "Enter First Name")
            txtFirstName.Focus()
            Return
        End If

        If (txtLastName.Text = String.Empty) Then
            If (MessageBox.Show("Do you want to enter a Last Name?", "Last Name", MessageBoxButtons.YesNo) = DialogResult.Yes) Then
                txtLastName.Focus()
                Return
            End If
        End If

        If (txtClass.Text = String.Empty) Then
            MessageBox.Show("Please enter a Class! Choose FR or SO, JR, SR", "Enter a Class")
            txtClass.Focus()
            Return
        End If

        Select Case txtClass.Text.ToUpper
            Case "FR", "SO", "JR", "SR"
                MessageBox.Show("You entered a valid class", "Valid Class")
            Case Else
                MessageBox.Show("Incorrect class entry. Must be FR or SO, JR, SR", "Invalid Class")
                Return
        End Select

        If (lstMajor.SelectionMode.ToString = "Other") Then
            If (MessageBox.Show("Would you like to change your major to Information Systems?", "Change your Major?", MessageBoxButtons.YesNo) = DialogResult.Yes) Then
                lstMajor.SelectedIndex = 0
            End If
        End If

        If ((radVB.Checked = True And chkVB.Checked = False) Or (radCSharp.Checked = True And chkCSharp.Checked = False) Or (radJavaScript.Checked = True And chkJavaScript.Checked = False) Or (radOther.Checked = True And chkOther.Checked = False)) Then
            MessageBox.Show("You cannot choose a language as your favorite if you do not know the language", "Inconsistent Language Selections")
            Return
        End If

    End Sub
End Class
