﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProject3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtClass = New System.Windows.Forms.TextBox()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblClass = New System.Windows.Forms.Label()
        Me.lblMajor = New System.Windows.Forms.Label()
        Me.grpProgrammingLang = New System.Windows.Forms.GroupBox()
        Me.radOther = New System.Windows.Forms.RadioButton()
        Me.radJavaScript = New System.Windows.Forms.RadioButton()
        Me.radCSharp = New System.Windows.Forms.RadioButton()
        Me.radVB = New System.Windows.Forms.RadioButton()
        Me.grpLangYouKnow = New System.Windows.Forms.GroupBox()
        Me.chkOther = New System.Windows.Forms.CheckBox()
        Me.chkJavaScript = New System.Windows.Forms.CheckBox()
        Me.chkCSharp = New System.Windows.Forms.CheckBox()
        Me.chkVB = New System.Windows.Forms.CheckBox()
        Me.btnCheckValues = New System.Windows.Forms.Button()
        Me.lstMajor = New System.Windows.Forms.ListBox()
        Me.grpProgrammingLang.SuspendLayout()
        Me.grpLangYouKnow.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblDate
        '
        Me.lblDate.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblDate.Location = New System.Drawing.Point(309, 15)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(92, 30)
        Me.lblDate.TabIndex = 0
        Me.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTime
        '
        Me.lblTime.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblTime.Location = New System.Drawing.Point(306, 57)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(95, 28)
        Me.lblTime.TabIndex = 1
        Me.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtFirstName
        '
        Me.txtFirstName.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtFirstName.Location = New System.Drawing.Point(127, 12)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(100, 20)
        Me.txtFirstName.TabIndex = 2
        '
        'txtLastName
        '
        Me.txtLastName.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtLastName.Location = New System.Drawing.Point(127, 42)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(100, 20)
        Me.txtLastName.TabIndex = 3
        '
        'txtClass
        '
        Me.txtClass.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtClass.Location = New System.Drawing.Point(127, 72)
        Me.txtClass.Name = "txtClass"
        Me.txtClass.Size = New System.Drawing.Size(100, 20)
        Me.txtClass.TabIndex = 4
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Location = New System.Drawing.Point(13, 12)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(110, 13)
        Me.lblFirstName.TabIndex = 5
        Me.lblFirstName.Text = "Enter Your First Name"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(13, 42)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(111, 13)
        Me.lblLastName.TabIndex = 6
        Me.lblLastName.Text = "Enter Your Last Name"
        '
        'lblClass
        '
        Me.lblClass.AutoSize = True
        Me.lblClass.Location = New System.Drawing.Point(36, 72)
        Me.lblClass.Name = "lblClass"
        Me.lblClass.Size = New System.Drawing.Size(85, 13)
        Me.lblClass.TabIndex = 7
        Me.lblClass.Text = "Enter Your Class"
        '
        'lblMajor
        '
        Me.lblMajor.AutoSize = True
        Me.lblMajor.Location = New System.Drawing.Point(13, 111)
        Me.lblMajor.Name = "lblMajor"
        Me.lblMajor.Size = New System.Drawing.Size(82, 13)
        Me.lblMajor.TabIndex = 8
        Me.lblMajor.Text = "Choose A Major"
        '
        'grpProgrammingLang
        '
        Me.grpProgrammingLang.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grpProgrammingLang.Controls.Add(Me.radOther)
        Me.grpProgrammingLang.Controls.Add(Me.radJavaScript)
        Me.grpProgrammingLang.Controls.Add(Me.radCSharp)
        Me.grpProgrammingLang.Controls.Add(Me.radVB)
        Me.grpProgrammingLang.Location = New System.Drawing.Point(155, 212)
        Me.grpProgrammingLang.Name = "grpProgrammingLang"
        Me.grpProgrammingLang.Size = New System.Drawing.Size(242, 72)
        Me.grpProgrammingLang.TabIndex = 9
        Me.grpProgrammingLang.TabStop = False
        Me.grpProgrammingLang.Text = "Choose Your Favorite Programming Language"
        '
        'radOther
        '
        Me.radOther.AutoSize = True
        Me.radOther.Location = New System.Drawing.Point(138, 43)
        Me.radOther.Name = "radOther"
        Me.radOther.Size = New System.Drawing.Size(51, 17)
        Me.radOther.TabIndex = 3
        Me.radOther.TabStop = True
        Me.radOther.Text = "Other"
        Me.radOther.UseVisualStyleBackColor = True
        '
        'radJavaScript
        '
        Me.radJavaScript.AutoSize = True
        Me.radJavaScript.Location = New System.Drawing.Point(138, 20)
        Me.radJavaScript.Name = "radJavaScript"
        Me.radJavaScript.Size = New System.Drawing.Size(75, 17)
        Me.radJavaScript.TabIndex = 2
        Me.radJavaScript.TabStop = True
        Me.radJavaScript.Text = "JavaScript"
        Me.radJavaScript.UseVisualStyleBackColor = True
        '
        'radCSharp
        '
        Me.radCSharp.AutoSize = True
        Me.radCSharp.Location = New System.Drawing.Point(18, 43)
        Me.radCSharp.Name = "radCSharp"
        Me.radCSharp.Size = New System.Drawing.Size(39, 17)
        Me.radCSharp.TabIndex = 1
        Me.radCSharp.TabStop = True
        Me.radCSharp.Text = "C#"
        Me.radCSharp.UseVisualStyleBackColor = True
        '
        'radVB
        '
        Me.radVB.AutoSize = True
        Me.radVB.Location = New System.Drawing.Point(18, 20)
        Me.radVB.Name = "radVB"
        Me.radVB.Size = New System.Drawing.Size(39, 17)
        Me.radVB.TabIndex = 0
        Me.radVB.TabStop = True
        Me.radVB.Text = "VB"
        Me.radVB.UseVisualStyleBackColor = True
        '
        'grpLangYouKnow
        '
        Me.grpLangYouKnow.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.grpLangYouKnow.Controls.Add(Me.chkOther)
        Me.grpLangYouKnow.Controls.Add(Me.chkJavaScript)
        Me.grpLangYouKnow.Controls.Add(Me.chkCSharp)
        Me.grpLangYouKnow.Controls.Add(Me.chkVB)
        Me.grpLangYouKnow.Location = New System.Drawing.Point(155, 127)
        Me.grpLangYouKnow.Name = "grpLangYouKnow"
        Me.grpLangYouKnow.Size = New System.Drawing.Size(242, 79)
        Me.grpLangYouKnow.TabIndex = 10
        Me.grpLangYouKnow.TabStop = False
        Me.grpLangYouKnow.Text = "Check Languages You Know"
        '
        'chkOther
        '
        Me.chkOther.AutoSize = True
        Me.chkOther.Location = New System.Drawing.Point(106, 43)
        Me.chkOther.Name = "chkOther"
        Me.chkOther.Size = New System.Drawing.Size(52, 17)
        Me.chkOther.TabIndex = 3
        Me.chkOther.Text = "Other"
        Me.chkOther.UseVisualStyleBackColor = True
        '
        'chkJavaScript
        '
        Me.chkJavaScript.AutoSize = True
        Me.chkJavaScript.Location = New System.Drawing.Point(106, 20)
        Me.chkJavaScript.Name = "chkJavaScript"
        Me.chkJavaScript.Size = New System.Drawing.Size(76, 17)
        Me.chkJavaScript.TabIndex = 2
        Me.chkJavaScript.Text = "JavaScript"
        Me.chkJavaScript.UseVisualStyleBackColor = True
        '
        'chkCSharp
        '
        Me.chkCSharp.AutoSize = True
        Me.chkCSharp.Location = New System.Drawing.Point(18, 43)
        Me.chkCSharp.Name = "chkCSharp"
        Me.chkCSharp.Size = New System.Drawing.Size(40, 17)
        Me.chkCSharp.TabIndex = 1
        Me.chkCSharp.Text = "C#"
        Me.chkCSharp.UseVisualStyleBackColor = True
        '
        'chkVB
        '
        Me.chkVB.AutoSize = True
        Me.chkVB.Location = New System.Drawing.Point(18, 20)
        Me.chkVB.Name = "chkVB"
        Me.chkVB.Size = New System.Drawing.Size(40, 17)
        Me.chkVB.TabIndex = 0
        Me.chkVB.Text = "VB"
        Me.chkVB.UseVisualStyleBackColor = True
        '
        'btnCheckValues
        '
        Me.btnCheckValues.Location = New System.Drawing.Point(85, 306)
        Me.btnCheckValues.Name = "btnCheckValues"
        Me.btnCheckValues.Size = New System.Drawing.Size(287, 47)
        Me.btnCheckValues.TabIndex = 11
        Me.btnCheckValues.Text = "&Check Values"
        Me.btnCheckValues.UseVisualStyleBackColor = True
        '
        'lstMajor
        '
        Me.lstMajor.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lstMajor.FormattingEnabled = True
        Me.lstMajor.Items.AddRange(New Object() {"Information Systems", "Information Technology", "Computer Science", "Other"})
        Me.lstMajor.Location = New System.Drawing.Point(16, 127)
        Me.lstMajor.Name = "lstMajor"
        Me.lstMajor.Size = New System.Drawing.Size(120, 56)
        Me.lstMajor.TabIndex = 12
        '
        'frmProject3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(424, 376)
        Me.Controls.Add(Me.lstMajor)
        Me.Controls.Add(Me.btnCheckValues)
        Me.Controls.Add(Me.grpLangYouKnow)
        Me.Controls.Add(Me.grpProgrammingLang)
        Me.Controls.Add(Me.lblMajor)
        Me.Controls.Add(Me.lblClass)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.lblFirstName)
        Me.Controls.Add(Me.txtClass)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.lblDate)
        Me.Name = "frmProject3"
        Me.Text = "The Check Values"
        Me.grpProgrammingLang.ResumeLayout(False)
        Me.grpProgrammingLang.PerformLayout()
        Me.grpLangYouKnow.ResumeLayout(False)
        Me.grpLangYouKnow.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDate As Label
    Friend WithEvents lblTime As Label
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtClass As TextBox
    Friend WithEvents lblFirstName As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents lblClass As Label
    Friend WithEvents lblMajor As Label
    Friend WithEvents grpProgrammingLang As GroupBox
    Friend WithEvents grpLangYouKnow As GroupBox
    Friend WithEvents btnCheckValues As Button
    Friend WithEvents lstMajor As ListBox
    Friend WithEvents radOther As RadioButton
    Friend WithEvents radJavaScript As RadioButton
    Friend WithEvents radCSharp As RadioButton
    Friend WithEvents radVB As RadioButton
    Friend WithEvents chkOther As CheckBox
    Friend WithEvents chkJavaScript As CheckBox
    Friend WithEvents chkCSharp As CheckBox
    Friend WithEvents chkVB As CheckBox
End Class
